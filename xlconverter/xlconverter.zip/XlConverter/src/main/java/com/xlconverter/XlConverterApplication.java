package com.xlconverter;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.xlconverter.converter.Convert;
@SpringBootApplication
public class XlConverterApplication {
	

	
	public static void main(String[] args) {
		SpringApplication.run(XlConverterApplication.class, args);
	Convert c = new Convert();
	c.importAndConvert();
	}
}
