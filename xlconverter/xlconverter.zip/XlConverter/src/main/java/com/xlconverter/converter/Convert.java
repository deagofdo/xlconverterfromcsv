package com.xlconverter.converter;

import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;



public class Convert {
/*public static void importAndConvert() {
	try(Workbook wb=new XSSFWorkbook(Files.newInputStream(Paths.get("C:\\Users\\543793\\Downloads\\BVSM\\BVSM.csv"),StandardOpenOption.READ )) ){
	System.out.println(wb.getSheetName(1));
	
		Sheet sheet= wb.getSheet(wb.getSheetName(1));
		int cellCount=sheet.getRow(0).getLastCellNum();
		Iterator rowI=sheet.rowIterator();
		while(rowI.hasNext()) {
			XSSFRow row=(XSSFRow) rowI.next();
			 int counter=0;
		while(counter< cellCount) {
			System.out.print(row.getCell(counter)+" ");
			counter++;
		}
		System.out.println();
		}
	} catch (IOException e) {
		e.printStackTrace();
	}
}*/ List<String> questions=new ArrayList<>();
	public  void importAndConvert() {
		System.out.println("inside import and convert");
		try(BufferedReader br =Files.newBufferedReader(Paths.get("BVSM.csv"))){
			
			
			
				questions=Arrays.asList(br.readLine().split(","));
/*				Runnable task=()->{
					System.out.println("runnable ");
					String line=null;
					List<String> answers=new ArrayList<>();
					try {
						while((line=br.readLine())!=null) {
							answers=Arrays.asList(line.split(","));
							writeToSheet(answers);
						}
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				
			
			};
			Thread thread= new Thread(task);
			thread.run();*/
			//answers.forEach(w->System.out.println(w.toString()));
				writeToSheet(null);
				 System.out.println("writing to file");
				try(FileOutputStream fw= new FileOutputStream("test.xlsx")) {
					
					
					workbook.write(fw);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				}
			catch(Exception e) {
				
			}

		}
	XSSFWorkbook workbook=null;
	XSSFSheet sheet=null;
	JSONObject config=null;
	int  rowCount=0;
	private synchronized void writeToSheet(List<String>answers) {
		System.out.println("write to sheet");
		
		if(workbook==null)
		{int cellCount=0;
			workbook=new XSSFWorkbook();
		try {
			config= (JSONObject) new JSONParser().parse(new FileReader("config.json"));
			sheet=workbook.createSheet(config.get("name")+"_sorted");
			JSONObject sections=(JSONObject) config.get("sections");
		if(!sections.isEmpty()) {
			Row row=sheet.createRow(rowCount++);
			int mergestart=0;
			int mergeEnd=0;
			for(Object o:sections.keySet()) {
				
				String heading=o.toString();
				System.out.println("heading="+heading);
				String[]numberOfQuestions=sections.get(heading).toString().split("-");
				int startNo=Integer.parseInt(numberOfQuestions[0]);
				int endNo=Integer.parseInt(numberOfQuestions[1]);
				if(startNo<endNo) {
					
					
					Cell cell=row.createCell(cellCount);
					cellCount=endNo;
					System.out.println("cellcount=="+cellCount);
					cell.setCellValue(heading);
					mergeEnd=endNo-1;
					sheet.addMergedRegion(new CellRangeAddress(0,0,mergestart,mergeEnd));
					mergestart=endNo;
					}
				else
					{throw new IndexOutOfBoundsException("enter valid question sequence number");}
			
			}}
		} catch (IOException | ParseException e) {
			e.printStackTrace();
		}
		/* try(FileOutputStream fw= new FileOutputStream("test.xlsx")) {
			 System.out.println("writing to file");
			
			workbook.write(fw);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		 
		 }
		if(rowCount==1) {
			System.out.println("writing questions");
		Row row=sheet.createRow(rowCount);
		int questionSize=questions.size();
		int flag=0;
		int cellCount=0;
	for(int i=0;i<questionSize;i++) {
		
		if(questions.get(i).toLowerCase().contains("wait time")||questions.get(i).toLowerCase().contains("process time")) {
			flag++;
			
		}
		Cell cell=row.createCell(cellCount++);
		cell.setCellValue(questions.get(i));
		if(flag==2) {
			Cell total=row.createCell(cellCount++);
			total.setCellValue("total time");
			flag=0;
			continue;
		}
	}
		}

		//row.createCell(arg0)
	}
	}

